module.exports = {
  content: ['./src/pages/**/*.tsx', './src/components/**/*.tsx'],
  theme: {
    extend: {
      colors: {

      },
    },
  },
  variants: {
    extend: {},
  },
  plugins: [],
}